package pt.upt.ei.lp.db;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Turma {
	  @Id
	  @GeneratedValue(strategy = GenerationType.TABLE)
	  private int id;
	  private int numero;
	  private String nome;
	  
	  
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String toString() {
		String st = "Turma id="+id+"  num="+numero+"  nome="+nome;
		return st;
	}

}
